package com.example.demo.servicio;

import org.springframework.stereotype.Service;

import com.example.demo.modelo.Cliente;

@Service
public class ClienteService_Logica {

    public Cliente calcular(Cliente cliente){
        double monto=cliente.getMonto();
        double interes=0;
        if(cliente.getMeses()<6){
            interes = monto * 0.01 * cliente.getMeses();
        }else if(cliente.getMeses()>=6 && cliente.getMeses()<10){
            interes = monto * 0.02 * cliente.getMeses();
        }else{
            interes = monto * 0.03 * cliente.getMeses();
        }

        double saldo = monto + interes;
        double cuotaMensual = saldo / cliente.getMeses();

        cliente.setInteres(interes);
        cliente.setSaldoTotal(saldo);
        cliente.setCuotaMensual(cuotaMensual);

        return cliente;
    }

}
