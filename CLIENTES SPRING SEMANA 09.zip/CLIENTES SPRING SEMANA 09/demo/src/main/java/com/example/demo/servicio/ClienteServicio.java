package com.example.demo.servicio;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.modelo.Cliente;

public interface ClienteServicio extends JpaRepository<Cliente, Integer>{
    
}
