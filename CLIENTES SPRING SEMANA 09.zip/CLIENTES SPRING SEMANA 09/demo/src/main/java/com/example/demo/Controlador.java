package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.modelo.Cliente;
import com.example.demo.servicio.ClienteService_Logica;
import com.example.demo.servicio.ClienteServicio;

@Controller
@RequestMapping("/")
public class Controlador {
    @Autowired
    ClienteServicio servicio;
    @Autowired 
    ClienteService_Logica logica;

    @GetMapping("/inicio")
    public String inicio(Model modelo){
        modelo.addAttribute("cliente", new Cliente());
        modelo.addAttribute("lista_Clientes", servicio.findAll());
        return "index";
    }

    @PostMapping("/agregar")
    public String agregar(@Validated Cliente c, Model modelo){
        c = logica.calcular(c); 
        servicio.save(c);
        return "redirect:/inicio";
    }

    @GetMapping("/eliminar/{num}")
    public String eliminar(@PathVariable int num, Model modelo){
        servicio.deleteById(num);
        return "redirect:/inicio";
    }

    @GetMapping("/buscar")
    public String buscar(@RequestParam int num, Model modelo){
        Optional<Cliente> resultado = servicio.findById(num);
        if(resultado.isPresent()){
            modelo.addAttribute("lista_Clientes", List.of(resultado.get()));
        }
        modelo.addAttribute("cliente", new Cliente());
        return "index";
    }
}
